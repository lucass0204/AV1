import csv
import json

def load_students(path):
    students = []
    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            # converte notas para float quando possível
            grades = []
            for k in ['grade1','grade2','grade3']:
                val = row.get(k,'').strip()
                try:
                    grades.append(float(val))
                except:
                    grades.append(0.0)
            students.append({
                'id': row.get('id','').strip(),
                'name': row.get('name','').strip(),
                'grades': grades
            })
    return students

def calculate_averages(students):
    for s in students:
        if s['grades']:
            s['average'] = sum(s['grades'])/len(s['grades'])
        else:
            s['average'] = 0.0
    return students

def top_student(students):
    if not students:
        return None
    return max(students, key=lambda s: s.get('average',0))

def export_report(students, path, fmt='csv'):
    if fmt == 'csv':
        with open(path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['id','name','average'])
            for s in students:
                writer.writerow([s['id'], s['name'], f"{s.get('average',0):.2f}"])
    else:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump([{'id':s['id'],'name':s['name'],'average':s.get('average',0)} for s in students], f, ensure_ascii=False, indent=2)
