import argparse
import os
import csv
import json
from .utils import load_students, calculate_averages, export_report, top_student

def build_parser():
    p = argparse.ArgumentParser(description='AV1 - Gerenciador simples de alunos')
    p.add_argument('--input', '-i', required=True, help='CSV de entrada com colunas: id,name,grade1,grade2,grade3')
    p.add_argument('--report', '-r', required=False, help='Caminho do relatório de saída')
    p.add_argument('--format', '-f', choices=['csv','json'], default='csv', help='Formato do relatório')
    p.add_argument('--top', action='store_true', help='Imprime o melhor aluno')
    return p

def main():
    parser = build_parser()
    args = parser.parse_args()
    students = load_students(args.input)
    students = calculate_averages(students)
    if args.top:
        best = top_student(students)
        if best:
            print(f"Melhor aluno: {best['name']} (id={best['id']}) - média={best['average']:.2f}")
        else:
            print('Nenhum aluno disponível.')
    if args.report:
        os.makedirs(os.path.dirname(args.report) or '.', exist_ok=True)
        export_report(students, args.report, args.format)
        print('Relatório gerado em', args.report)

if __name__ == '__main__':
    main()
