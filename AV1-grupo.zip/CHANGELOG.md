# Changelog

## 2025-10-03  - Reescrita inicial
- Projeto criado do zero como reimplementação para AV1.
- Implementação de CLI para carregar CSV com alunos, calcular médias, gerar relatório CSV/JSON.
- Testes unitários com pytest.
- Arquivos: README, CONTRIBUTORS, CHANGELOG, LICENSE.
