# Contributors (Autores do Trabalho)

- Kauan Vieira Xavier - 06004975
- João Marcellus Peçanha Rosa - 06003360
- Nícolas Eduardo Teixeira De Assis - 06004043
- Lucas Domingos da Silva Miranda - 06004981
- Márcio Josué Branco Carnevali - 06003553
- Mohamad Lobo Azevedo - 06003782

Cada membro contribuiu na reescrita do projeto e nas etapas de teste e documentação.
