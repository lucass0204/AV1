from src.utils import load_students, calculate_averages, top_student
import os

def test_load_and_avg(tmp_path):
    p = tmp_path / 's.csv'
    p.write_text('id,name,grade1,grade2,grade3\n1,Ana,8,7,9\n2,Bru,6,7,6\n')
    students = load_students(str(p))
    students = calculate_averages(students)
    assert len(students) == 2
    assert round(students[0]['average'],2) == 8.0
    assert round(students[1]['average'],2) == 6.33 or round(students[1]['average'],2) == 6.0

def test_top_student(tmp_path):
    p = tmp_path / 's.csv'
    p.write_text('id,name,grade1,grade2,grade3\n1,Ana,8,7,9\n2,Carlos,9,9,9\n')
    students = load_students(str(p))
    students = calculate_averages(students)
    top = top_student(students)
    assert top['name'] == 'Carlos'
